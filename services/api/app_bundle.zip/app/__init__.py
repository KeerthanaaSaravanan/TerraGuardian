"""TerraGuardian AI — Backend API."""
