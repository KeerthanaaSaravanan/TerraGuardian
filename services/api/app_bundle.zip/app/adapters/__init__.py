"""External data source adapters."""
